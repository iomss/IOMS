<template>
  <div>
    myjob
  </div>
</template>

<script>

export default {
  name: 'Myjob',
  data() {
    return {
    }
  },
  computed: {
  },
  created() {
  }
}
</script>
