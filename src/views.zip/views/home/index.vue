<template>
  <div>
    index
  </div>
</template>

<script>

export default {
  name: 'Index',
  data() {
    return {
    }
  },
  computed: {
  },
  created() {
  }
}
</script>
