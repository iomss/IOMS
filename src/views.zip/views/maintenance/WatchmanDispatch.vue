<!-- 值班人员派单页面 -->
<template>
  <div>
    <el-row>
      <el-col>
        <div class="panel">
          <div class="header">
            <h4>值班人员派单</h4>
            <div class="select">
              <el-form ref="formData" :model="formData" label-width="90px" :rules="formDatarules">
                <el-form-item label="报修位置" prop="positionId">
                  {{ formData.positionName }}
                </el-form-item>
                <el-form-item label="资产名称" prop="equipment">
                  {{ formData.equipment }}
                </el-form-item>
                <el-form-item label="资产编码" prop="code">
                  {{ formData.code }}
                </el-form-item>
                <el-form-item label="故障时间" prop="failureTime">
                  <el-date-picker v-model="formData.failureTime" type="datetime" placeholder="故障时间" />
                </el-form-item>
                <el-form-item label="报修时间" prop="reportTime">
                  <el-date-picker v-model="formData.reportTime" type="datetime" placeholder="报修时间" />
                </el-form-item>
                <el-form-item label="故障类型" class="showtishi" prop="equipmentFaultId">
                  <el-select v-model="formData.equipmentFaultId" filterable remote :remote-method="remoteMethodefaultID" :loading="loading" placeholder="故障类型" size="small" @focus="remoteMethodefaultID">
                    <el-option v-for="item in faultData" :key="item.id" :label="item.name" :value="item.id" />
                  </el-select>
                  <i class="fa fa-plus" aria-hidden="true" @click="creatorder()" />
                </el-form-item>
                <el-form-item label="故障描述" class="total" prop="description">
                  <el-input v-model="formData.description" placeholder="故障描述" size="small" />
                </el-form-item>
                <el-form-item label="录入人" prop="reporterName">
                  {{ dangqianUser.trueName }}
                </el-form-item>
                <el-form-item label="报修人" prop="reporterName">
                  <el-input v-model="formData.reporterName" placeholder="报修人" size="small" />
                </el-form-item>
                <el-form-item label="故障级别" class="showtishi" prop="repairLevelId">
                  <el-select v-model="formData.repairLevelId" filterable placeholder="故障级别" size="small">
                    <el-option v-for="item in levelData" :key="item.id" :label="item.name" :value="item.id" />
                  </el-select>
                  <el-tooltip placement="right">
                    <div slot="content" style="width:300px;">一级故障（重大设备故障）：<br>
                      指机电系统出现系统瘫痪或局部瘫痪造成收费运营不能正常进行的故障。出现一级故障时要立即赶赴现场维修，要求在8小时内完成维修任务。其中现有外联维修协议包括的维修范围：①柴油发电机故障②UPS故障③光缆线路故障④通信设备故障⑤收费、监控系统故障⑥情报板故障⑦供配电系统故障。<br>
                      二级故障（较大设备故障）：<br>
                      指机电系统设备出现局部故障，对正常的收费监控管理造成较大影响的设备故障。出现二级故障时要求在72小时（3天）内完成维修任务。<br>
                      三级故障（一般设备故障）：<br>
                      指机电系统设备出现单一设备故障，对正常收费、监控管理影响较少或没有影响的故障。出现三级故障时要求在120小时（5天）内完成维修任务。
                    </div>
                    <el-button>说明</el-button>
                  </el-tooltip>
                </el-form-item>
                <el-form-item label="指定工程师" prop="repairUserId">
                  <el-select v-model="formData.repairUserId" filterable remote :remote-method="remoteMethoduserId" :loading="loading" placeholder="指定工程师" size="small" @focus="remoteMethoduserId">
                    <el-option v-for="item in userData" :key="item.id" :label="item.trueName" :value="item.id" />
                  </el-select>
                </el-form-item>
                <el-form-item class="total">
                  <el-button type="primary" size="small" icon="el-icon-search" @click="createWorker()">派单</el-button>
                  <el-button type="primary" size="small" icon="el-icon-search" @click="cancelWorker()">取消</el-button>
                </el-form-item>
              </el-form>
            </div>
            <el-dialog title="添加故障类型" :visible.sync="changeActiveVisible" :close-on-press-escape="false" :close-on-click-modal="false" width="600px">
              <el-form ref="formAdd" :model="formAdd" label-width="90px" :rules="formAddrules">
                <el-form-item label="设备种类" prop="equipmentId" class="total">
                  <el-select v-model="formAdd.equipmentId" filterable remote :remote-method="remoteMethodequipmentID" :loading="loading" placeholder="设备种类" size="small" @focus="remoteMethodequipmentID">
                    <el-option v-for="item in equipmentData" :key="item.id" :label="item.name" :value="item.id" />
                  </el-select>
                </el-form-item>
                <el-form-item label="故障名称" prop="name" class="total">
                  <el-input v-model="formAdd.name" placeholder="故障名称" />
                </el-form-item>
              </el-form>
              <span slot="footer" class="dialog-footer">
                <el-button type="primary" @click="creatderrortype()">确 定</el-button>
                <el-button type="primary" @click="changeActiveVisible=false">关闭</el-button>
              </span>
            </el-dialog>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
export default {
  components: {
  },
  data() {
    return {
      dangqianUser: {// 当前登陆用户
        userName: this.$cookie.get('trueName'),
        id: this.$cookie.get('id'),
        trueName: this.$cookie.get('trueName')
      },
      loading: false, // 远程搜索
      changeActiveVisible: false,
      formData: {
        code: '',
        assetId: '',
        positionId: '',
        positionName: '',
        equipment: '',
        equipmentId: '',
        failureTime: '',
        reportTime: '',
        equipmentFaultId: '',
        reporterName: '',
        description: '',
        repairLevelId: '',
        repairUserId: ''
      },
      formAdd: {
        equipmentId: '',
        name: ''
      },
      equipmentData: [], // 设备种类数据
      faultData: [], // 故障类型数据
      levelData: [], // 故障级别数据
      userData: [], // 可指派人员数据
      formDatarules: {
        failureTime: [
          { type: 'date', required: true, message: '请选择故障时间', trigger: 'change' }
        ],
        reportTime: [
          { type: 'date', required: true, message: '请选择报修时间', trigger: 'change' }
        ],
        equipmentFaultId: [
          { required: true, message: '故障类型不可为空', trigger: 'change' }
        ],
        repairLevelId: [
          { required: true, message: '故障级别不可为空', trigger: 'change' }
        ]
      },
      formAddrules: {
        equipmentId: [
          { required: true, message: '设备种类不可为空', trigger: 'change' }
        ],
        name: [
          { required: true, message: '故障名称不可为空', trigger: 'change' }
        ]
      },
      faultpage: {// 故障类型分页
        pageNumber: 1,
        pageSize: 50,
        pageCount: '',
        equipmentId: undefined
      },
      equipmentpage: {// 资产类别分页
        pageNumber: 1,
        pageSize: 50,
        pageCount: ''
      },
      userpage: {// 指定工程师分页
        pageNumber: 1,
        pageSize: 50,
        pageCount: ''
      }
    }
  },
  computed: {},
  watch: {
    'formData.equipment': {
      handler: function(val, oldVal) {
        this.faultData.equipmentId = this.formData.equipmentId
        this.$axios.get('/api/Meta/Fault?equipmentId=' + this.formData.equipmentId).then(res => {
          this.faultData = res.data
          this.faultpage.pageCount = res.pageCount
        })
      },
      // 深度观察
      deep: true
    }
  },
  mounted() {
    this.getlevelData()
    this.getfaultData()
    this.getequipmentData()
    this.getuserData()
    this.getData()
  },
  methods: {
    getlevelData() {
      // 获取维修级别
      this.$axios.get('/api/Meta/RepairLevel').then(res => {
        this.levelData = res.data
        this.formData.repairLevelId = this.levelData[1].id
      })
    },
    getfaultData() {
      // 获取故障类型
      this.$axios.get('/api/Meta/Fault?equipmentId=' + this.formData.equipmentId + '&pageSize=' + this.faultpage.pageSize + '&pageNumber=' + this.faultpage.pageNumber).then(res => {
        this.faultData = this.faultData.concat(res.data)
        this.faultpage.pageCount = res.pageCount
      })
    },
    getequipmentData() {
      // 获取资产类别
      this.$axios.get('/api/Meta/equipment?pageSize=' + this.equipmentpage.pageSize + '&pageNumber=' + this.equipmentpage.pageNumber).then(res => {
        this.equipmentData = this.equipmentData.concat(res.data)
      })
    },
    getuserData() {
      // 获取用户
      this.$axios.get('/api/User?Dispatch=true&pageSize=' + this.userpage.pageSize + '&pageNumber=' + this.userpage.pageNumber).then(res => {
        this.userData = this.userData.concat(res.data)
        this.userpage.pageCount = res.pageCount
      })
    },
    remoteMethodefaultID(query) {
      this.loading = true
      let querytext = ''
      querytext = typeof (query) === 'string' ? query : ''
      this.$axios.get('/api/Meta/Fault?equipmentId=' + this.formData.equipmentId + '&text=' + querytext).then(res => {
        this.loading = false
        this.faultData = res.data
      })
    },
    remoteMethoduserId(query) {
      this.loading = true
      let querytext = ''
      querytext = typeof (query) === 'string' ? query : ''
      this.$axios.get('/api/User?Dispatch=true&pageSize=' + this.userpage.pageSize + '&pageNumber=' + this.userpage.pageNumber + '&text=' + querytext).then(res => {
        this.loading = false
        this.userData = res.data
      })
    },
    remoteMethodequipmentID(query) {
      this.loading = true
      let querytext = ''
      querytext = typeof (query) === 'string' ? query : ''
      this.$axios.get('/api/Meta/Equipment?text=' + querytext).then(res => {
        this.loading = false
        this.equipmentData = res.data
      })
    },
    getData() { // 获取当前数据
      const _this = this
      this.formData.assetId = window.location.href.split('/')[window.location.href.split('/').length - 1]
      this.$axios.get('/api/Assets/' + this.formData.assetId).then(res => {
        _this.formData.positionId = res.positionId
        _this.formData.equipment = res.equipment.name
        _this.formData.equipmentId = res.equipment.id
        _this.formData.positionId = res.position.id
        _this.formData.positionName = res.position.crumbName
        _this.formData.code = res.code
      })
    },
    createWorker() { // 提交派单按钮方法
      const _this = this
      this.$refs.formData.validate(valid => {
        if (valid) {
          _this.$axios.post('/api/RepairOrder', _this.formData).then(res => {
            _this.$message.success('录入成功')
            // 跳转维修单录入页面
            _this.$router.push('/maintenance/WatchmanAssetslist')
            // 关闭派单页面
            console.log(_this.$router.currentRoute.fullPath)
            this.$store.dispatch('tagsView/delAllViews', _this.$router.currentRoute.fullPath)
          })
        }
      })
    },
    handleSelectionChange(val) { // 表单选中行
      this.multipleSelection = val
    },
    creatorder() { // 创建故障类型
      this.changeActiveVisible = true// 打开弹框
    },
    creatderrortype() { // 添加故障类型弹框确定方法
      console.log(this)
      this.$refs.formAdd.validate(valid => {
        if (valid) {
          // 提交数据
          this.$axios.post('/api/Meta/Fault', this.formAdd).then(res => {
            this.faultData = res.data
          })
          // 刷新数据
          this.$axios.get('/api/Meta/Fault').then(res => {
            this.faultData = res.data
          })
          // 隐藏弹框
          this.changeActiveVisible = false
        }
      })
    },
    cancelWorker() { // 取消派单
      // 关闭派单页面
      console.log(this.$router.currentRoute.fullPath)
      this.$store.dispatch('tagsView/delAllViews', this.$router.currentRoute.fullPath)
      // 跳转维修单录入页面
      this.$router.push('/maintenance/WatchmanAssetslist')
    }
  }
}
</script>
<style lang='scss' scoped>
.header {
  width: 100%;
}
.el-form-item {
  width: 49%;
  display: inline-block;
}
.el-select {
  margin-bottom: 5px;
  width: 100%;
}
.el-input {
  width: 100%;
}

.total {
  width: 98%;
  text-align: center;
}
.showtishi {
  .el-select {
    display: inline-block;
    width: 90%;
  }
  .el-button {
    padding: 8px 15px;
  }
}
</style>
